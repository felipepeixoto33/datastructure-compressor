package unifor.programming;

public class No {
    Object dado;
    No proximo;

    public No(Object dado){
        this.dado = dado;
        this.proximo = null;
    }
}
